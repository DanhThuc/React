import React, { Component } from 'react';
import './App.css';
import Header from './Components/Header';
import Phones from './Components/Phones';
import Message from './Components/Message';
import Carts from './Components/Carts';
import Foodter from './Components/Foodter';



class App extends Component {
  render() {
    return (
      <div>
      <Header/>
      <section className=" ">
   
      <h1 className="h1">Điện thoại nổi bật nhất</h1>
      <Phones />
      <Message />
      
      </section>
      <div className="wrap_cart">
      <Carts/>
     
      </div>
      <Foodter/>
      </div>
    );
  }
}

export default App;
