import React, { Component } from 'react';
import Phone from './Phone';
import {connect} from 'react-redux';

class Phones extends Component {
  showProduct(phones){
    var result=null;
    if(phones.length>0){
      result = phones.map((phone,index)=>{
         if(index%4===0){
           return <li className="feature" key={index}>
            
              <Phone phone={phone} km ={index}/>
     
           </li>
         }
         else 
        return  <li key={index}>
        <Phone phone={phone} km ={index}/>
        </li>
      });
      
    }
    return result;
  };
  render() {
    let {phones} = this.props;
    console.log(phones);
    
    return (
   
        <ul className="homeproduct">
          {this.showProduct(phones)}
        </ul>
    
     
    );
}
}
const mapStateToProps = state =>{
  return {
    phones : state.phones
  }
}

export default connect(mapStateToProps,null) (Phones);