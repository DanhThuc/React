export const MS_ADD_TO_CART_SUCCESS = 'Mua hàng thành công!';
export const MS_UPDATE_TO_CART_SUCCESS = 'Cập nhật giỏ hàng thành công!';
export const MS_DELETE_TO_CART_SUCCESS = 'Xóa sản phẩm khỏi giỏ hàng thành công!';
export const MS_CART_EMPTY = 'Chưa có sản phẩm nào trong giỏ hàng';
export const MS_WELLCOME = 'Chào mừng tới với website';