import React, { Component } from 'react';
import {connect} from 'react-redux';
import { Phones } from '../Components/Phones';

class PhonesContainer extends Component {
  
  render() {
    let {phones} = this.props;
    
    return (
        <Phones phones ={phones} />
    );
}
}
const mapStateToProps = state =>{
  return {
    phones : state.phones
  }
}

export default connect(mapStateToProps,null) (PhonesContainer);