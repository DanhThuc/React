import  { combineReducers } from 'redux';
import phones from './phones';

const appReducers = combineReducers({
    phones
});

export default appReducers;