import React, { Component } from 'react';

class CartItem extends Component {
    promotion = (item) =>{
        var result = [];
        result.push(<span key={0} className="title">
                        <label>{item.promotions.length} khuyến mãi</label>
                    </span>);
        for(let i =0;i<item.promotions.length;i++){
            result.push(
                            <span key={i+1}>
                                {item.promotions[i].content}
                            </span>
            );
        }
        return result;
    }
    onDeleteCartItem=(id) =>{
        this.props.onDeleteCartItem(id);
    }
    onAddQuantity=(id,num,quantity)=>{
        this.props.onAddQuantity(id,num,quantity);
    }
    showCart = (cart) => {
        var result = [];
        for(let i=0;i<cart.length;i++){
            
            result.push(
                <li key ={i} className=" justadded" data-value="190321" id="item190321" data-num="4" data-cat="42">

                    <div className="colimg">
                        <a href=".">
                            <img width="55" alt={cart[i].phone.des} src={cart[i].phone.image}/>
                        </a>
                        <button type="button"
                        onClick ={()=>{this.onDeleteCartItem(cart[i].phone.id)}}
                        className="delete"><span></span>Xóa</button>
                    </div>
                    <div className="colinfo">
                        <strong>{cart[i].phone.price}$</strong>
                        <a href=".">{cart[i].phone.name}</a>
                        <div className="promotion  webnote">
                            {this.promotion(cart[i].phone)}
                        </div>
                        <div className="choosenumber">
                            <input type="hidden" className="hdQuantity" name="ListNone[0].Quantity" value="1"/>
                            <button
                            onClick={()=>this.onAddQuantity(cart[i].phone.id,1,cart[i].quantity)}
                            >
                                +
                            </button>
                            <div className="number">{cart[i].quantity}</div>
                            <button
                            onClick={()=>this.onAddQuantity(cart[i].phone.id,-1,cart[i].quantity)}
                            >
                                -
                            </button>
                        </div>
                        <div className="clr"></div>
                        <input type="hidden" className="hdIsBuyComBo" name="ListNone[0].IsBuyComBo" value="false" />

                    </div>
                </li>
            );
        }
        return result;
     }
    render() {
        return (
            <ul className="listorder">
               {this.showCart(this.props.children)}
            </ul>
        );
    }
}

export default CartItem;

