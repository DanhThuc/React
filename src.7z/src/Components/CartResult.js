import React, { Component } from 'react';

class CartResult extends Component {

    showSumAmount =(children)=>{
        let result=0;
        children.forEach(element => {
            result+=element.quantity;
        });
        return result;
    }
    showTotalAmount=(children)=>{
        let result =0;
        children.forEach(element=>{
            result +=element.quantity*element.phone.price;
        });
        return result;
    }
    onChange = () => {
    }
    render() {
      var {children} = this.props;
        return (
            <div className="area_total">
                <div className="total ">
                    <b>Tổng tiền ({this.showSumAmount(children)} sản phẩm):</b>
                    <strong id="totalOr" data-val="750000.0">{this.showTotalAmount(children)}$</strong>
                </div>
                <div id="cod" className="hide">
                    <span>Phí vận chuyển:</span>
                    <span className="price-color">+</span>
                </div>
                <div id="promotiondiscount" className="hide">
                    <span>Giảm:</span>
                    <span className="price-color">-</span>
                </div>


                <div id="totalSum" className="total hide">
                    <b>Cần thanh toán:</b>
                    <strong id="sum" data-val="750000.0">750.000₫</strong>
                </div>
                <div id="areaCoupon" className="">
                    <div className="freeship hide">
                        <i className="iconcart-check"></i> Đơn hàng được
                    <b>miễn phí</b> giao hàng</div>
                    <div className="textcode">
                        Sử dụng mã giảm giá
                </div>

                </div>
            </div>
        );
    }
}

export default CartResult;
