import React, { Component } from 'react';


class Message extends Component {
  render() {
    return (
        
        <h2 className="h2game">Ưu đãi khi mua Phụ Kiện cùng Samsung Galaxy A7 (2018) 128GB</h2>

    );
}
}

export default Message;