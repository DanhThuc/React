import * as Types from '../constain/ActionTypes';
import * as Mess from '../constain/Message';

export const actAddToCart = (phone, quantity) =>{
    return{
        type : Types.ADD_TO_CART,
        phone ,
        quantity
    }
}
export const actDeleteCartItem = (id) =>{
    return{
        type : Types.DELETE_CART_ITEM,
        id
    }
}
export const actIncreaseQuantity = (id,num) =>{
    return{
        type : Types.INCREASE_QUANTITY,
        id,
        num
    }
}



// mes

export const actMessWelcome = () =>{
    return{
        type : Mess.MS_WELLCOME
    }
}
export const actMessAddToCartSuccess = () =>{
    return{
        type : Mess.MS_ADD_TO_CART_SUCCESS
    }
}
export const actMessDeleteToCartSuccess = () =>{
    return{
        type : Mess.MS_DELETE_TO_CART_SUCCESS
    }
}
export const actUpdateToCartSuccess = () =>{
    return{
        type : Mess.MS_UPDATE_TO_CART_SUCCESS
    }
}