import React, { Component } from 'react';
import { connect } from 'react-redux';
import Phone from '../Components/Phone';
import PropTypes from 'prop-types';
import CartItem from '../Components/CartItem';
import CartResult from '../Components/CartResult';
import {actAddToCart, actDeleteCartItem, actMessAddToCartSuccess, actMessDeleteToCartSuccess, actIncreaseQuantity, actUpdateToCartSuccess} from '../actions/index';

class CartContainer extends Component {
    onDeleteCartItem=(id)=>{
        this.props.onDeleteCartItem(id);
    }
    onAddQuantity =(id,num,quantity)=>{
        if(quantity==1 && num===-1)
        {
            this.props.onDeleteCartItem(id);
        }
        else
        this.props.onAddQuantity(id,num);
    }
    render() {
        var cart = this.props.cart;

        return (
            <div className="wrap_cart">
            <CartItem 
            onDeleteCartItem ={this.onDeleteCartItem}
            onAddQuantity = {this.onAddQuantity}
            >{cart}</CartItem>
            <CartResult>{cart}</CartResult>
            </div>
        );
    }
}

CartContainer.propTypes = {
    cart: PropTypes.arrayOf(
        PropTypes.shape({
            phone: PropTypes.shape({
                id: PropTypes.number.isRequired,
                name: PropTypes.string.isRequired,
                image: PropTypes.string.isRequired,
                des: PropTypes.string.isRequired,
                price: PropTypes.number.isRequired,
                inventory: PropTypes.number.isRequired,
                rating: PropTypes.number.isRequired,
                numberReview: PropTypes.number.isRequired,
                promotions: PropTypes.arrayOf(
                    PropTypes.shape({
                        content: PropTypes.string.isRequired
                    })
                ).isRequired
            }).isRequired,
            quantity: PropTypes.number.isRequired
        }).isRequired
    ).isRequired
};
const mapStateToProps = state => {
    return {
        cart : state.cart
    }
}
const mapDispatchToProps = (dispatch,action) => {
    return {
        onDeleteCartItem:(id) =>{
            dispatch(actDeleteCartItem(id));
            dispatch(actMessDeleteToCartSuccess());
        },
        onAddQuantity: (id,num) =>{
            dispatch(actIncreaseQuantity(id,num));
            dispatch(actUpdateToCartSuccess());
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(CartContainer);