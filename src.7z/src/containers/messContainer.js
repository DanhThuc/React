import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Message from '../Components/Message';
 

class MessContainer extends Component {
    render() {
        var {mess} = this.props;
        return (
            <Message>{mess}</Message>
        );
    }
}

MessContainer.propTypes = {
    mess: PropTypes.string.isRequired
};
const mapStateToProps = state => {
    return {
        mess : state.mess
    }
}

export default connect(mapStateToProps, null)(MessContainer);