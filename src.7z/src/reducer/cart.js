import * as types from '../constain/ActionTypes'
import * as mess from '../constain/Message';

var data= JSON.parse(localStorage.getItem('CART'));
var initialState = data?data:[];
const cart = (state = initialState, action)=>{
    let {phone,quantity} = action;
    switch(action.type){
        case types.ADD_TO_CART :
            var index = state.findIndex(a=>a.phone.id===action.phone.id)
            if(index>-1){
                state[index].quantity+=quantity;
            }
            else{
                state.push({
                    phone,
                    quantity
                });
            }
            localStorage.setItem('CART',JSON.stringify(state));
            return [...state];
        case types.DELETE_CART_ITEM :
            var index = state.findIndex(a=>a.phone.id===action.id)
            state.splice(index,1);
            localStorage.setItem('CART',JSON.stringify(state));
            return [...state];
        case types.INCREASE_QUANTITY :
            var index =state.findIndex(a=>a.phone.id===action.id);
            state[index].quantity+=action.num;
            localStorage.setItem('CART',JSON.stringify(state));
            return [...state];
        default : return [...state];
    }
}
export default cart;

