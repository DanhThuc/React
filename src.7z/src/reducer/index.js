import  { combineReducers } from 'redux';
import phones from './phones';
import cart from './cart';
import mess from './mess';


const appReducers = combineReducers({
    phones,
    cart,
    mess
});

export default appReducers;