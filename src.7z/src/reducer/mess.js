import * as Mess from '../constain/Message';

var data= JSON.parse(localStorage.getItem('MESS'));
var initialState = data?data:Mess.MS_WELLCOME;

const cart = (state = initialState, action)=>{
    switch(action.type){
        case Mess.MS_WELLCOME:
            localStorage.setItem('MESS',JSON.stringify(Mess.MS_WELLCOME));
            return Mess.MS_WELLCOME;
        case Mess.MS_ADD_TO_CART_SUCCESS :
            localStorage.setItem('MESS',JSON.stringify(Mess.MS_ADD_TO_CART_SUCCESS));
            return Mess.MS_ADD_TO_CART_SUCCESS;
        case Mess.MS_CART_EMPTY :
            localStorage.setItem('MESS',JSON.stringify(Mess.MS_CART_EMPTY));
            return Mess.MS_CART_EMPTY;
        case Mess.MS_DELETE_TO_CART_SUCCESS :
            localStorage.setItem('MESS',JSON.stringify(Mess.MS_DELETE_TO_CART_SUCCESS));
            return Mess.MS_DELETE_TO_CART_SUCCESS;
        case Mess.MS_UPDATE_TO_CART_SUCCESS :
            localStorage.setItem('MESS',JSON.stringify(Mess.MS_UPDATE_TO_CART_SUCCESS));
            return Mess.MS_UPDATE_TO_CART_SUCCESS;
        default : return Mess.MS_WELLCOME;
    }
}
export default cart;

