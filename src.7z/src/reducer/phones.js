var initialState = [{
    id :1,
    name : "Samsung Galaxy A7 (2018) 128GB",
    image: "https://cdn.tgdd.vn/Products/Images/42/192003/samsung-galaxy-a9-2018-blue-400x400.jpg",
    des : "xx",
    price : 500,
    inventory : 10,
    rating : 4,
    numberReview : 40,
    promotions : [
        {
            content: "- Cơ hội trúng 61 xe Wave Alpha khi trả góp Home Credit",
        },
        {
            content: "- Ưu đãi Galaxy uống cafe & xem phim cuối tuần trị giá 900.000đ",
        },
        {
            content: "- Giảm 1.5 triệu cho khách hàng sử dụng điện thoại Samsung chính hãng",
        }
       
    ]
    
},
{
    id :2,
    name : "OPPO F9",
    image: "https://cdn.tgdd.vn/Products/Images/42/182153/oppo-f9-tim-600x600.jpg",
    des : "OPPO F9",
    price : 123,
    inventory : 10,
    rating : 4,
    numberReview : 56,
    promotions : [
        {
            content: "Tặng Phiếu mua hàng 100.000đ (từ 14/12)",
        }
    ]
},
{
    id :3,
    name : "iPhone Xs Max 64GB",
    image: "https://cdn.tgdd.vn/Products/Images/42/190321/iphone-xs-max-gray-600x600.jpg",
    des : "iPhone Xs Max 64GB",
    price : 239,
    inventory : 10,
    rating : 5,
    numberReview : 126,
    promotions : [
        {
            content: "-  Mua kèm tai nghe AirPods Apple với ưu đãi giảm 1 triệu",
        },
        
    ]
},
{
    id :4,
    name : "Samsung Galaxy Note 9",
    image: "https://cdn.tgdd.vn/Products/Images/42/154897/samsung-galaxy-note-9-black-600x600-600x600-400x400.jpg",
    des : "xx",
    price : 500,
    inventory : 10,
    rating : 3,
    numberReview : 30,
    promotions : [
        {
            content: "- Tặng Phiếu mua hàng 100.000đ và nhiều K.mãi khác"
        },
       
        
    ]
}
,
{
    id :5,
    name : "Vsmart Joy 1",
    image: "https://cdn.tgdd.vn/Products/Images/42/196608/vsmart-joy-1-white-600x600.jpg",
    des : "Vsmart Joy 1",
    price : 230,
    inventory : 10,
    rating : 5,
    numberReview : 330,
    promotions : [
        {
            content: "- Tặng Phiếu mua hàng 100.000đ và nhiều K.mãi khác",
        },
        
    ]
}
,
{
    id :6,
    name : "iPhone 7 Plus 32GB",
    image: "https://cdn.tgdd.vn/Products/Images/42/78124/iphone-7-plus-32gb-hh-600x600.jpg",
    des : "iPhone 7 Plus 32GB",
    price : 432,
    inventory : 10,
    rating : 3,
    numberReview : 30,
    promotions : [
        {
            content: "-  Mua kèm tai nghe Bluetooth AirPods Apple với ưu đãi giảm 1 triệu và nhiều KM khác",
        },
        
    ]
}
]
const phones = (state = initialState, action)=>{
    switch(action.type){
        default :  return [...state];
    }
}
export default phones;

